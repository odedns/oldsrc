
/**
 * the my_dir program.
 *
 * Oded Nissan 059183384
 */

#include <stdio.h>
#include <string.h>
#include "ext2_fs.h"
#include "my_fs.h"




int main(int argc,char **argv)
{
	char *p;
	struct ext2_dir_entry_2 *dir_entry;
		

	p = get_default_dir();
	init();

	if(!strcmp(p,"/")) {
		find_entry(p, 1, print_dir_entry);
	} else {

		dir_entry = find_path(p);
		if(NULL == dir_entry) {
			printf("path not found %s\n",p);
			find_entry(p, 1, print_dir_entry);
			cleanup();
			return(1);
		}

		find_entry(p, dir_entry->inode-1, print_dir_entry);
	}

	cleanup();
	return(0);


}

