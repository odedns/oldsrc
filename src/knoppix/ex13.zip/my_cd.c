
/**
 * the my_cd program.
 *
 * Oded Nissan 059183384
 */
#include <stdio.h>
#include <string.h>
#include "ext2_fs.h"
#include "my_fs.h"




int main(int argc,char **argv)
{
	char path[255];
	struct ext2_dir_entry_2 *dir_entry;
		
	if(argc < 2) {
		printf("usage: %s <dir>\n",argv[0]);
		return(1);

	}

	strcpy(path,argv[1]);
	init();


	dir_entry = find_path(path);
	if(NULL != dir_entry) {
		printf("change dir to: %s\n",argv[1]);
		set_path(argv[1]);
	} else {
		printf("could not cd to: %s\n",argv[1]);
	}

	cleanup();
	return(0);


}

