
/**
 * header file for my_fs.c
 *
 * Oded Nissan 059183384.
 */

#define BOOT_BLOCK_SIZE 1024
#define DIR_FNAME "/tmp/.myext2"
#define MAX_PATH 256


/**
 * safe version of fread.
 * in case of error close the file and exit.
 */

size_t safe_fread(void *ptr,size_t size, size_t nmemb, FILE *stream);
/**
 * print a dir entry.
 **/
void print_dir_entry(struct ext2_dir_entry_2 *entry);
/*
 * fseek to the inode table entry and search for the 
 * path component.
 */
struct ext2_dir_entry_2 *find_entry(char *path, int inode,
				void(*print_entry)(struct ext2_dir_entry_2*));

/**
 * find the full path.
 * break into path components and search for each path componenet.
 */
struct ext2_dir_entry_2 *find_path(char *full_path);

struct ext2_dir_entry_2 *read_dir(int block);
/**
 * init read  the super block and
 * group descriptor.
 */
void init();

/*
 * print message close the file
 * and exit.
 */
void fatal_error(char *msg);

void cleanup();
struct ext2_inode *read_inode_table(int entry);
void set_path(char *path);
char *get_default_dir();
