/**
 * This file contains functions
 * for accessing the ext2 file system.
 *
 * Oded Nissan 059183384
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "ext2_fs.h"
#include "my_fs.h"


FILE *fp;
int block_size = BOOT_BLOCK_SIZE;
int inode_table_block;


/**
 * safe version of safe_fread.
 * in case of error close the file and exit.
 */
size_t safe_fread(void *ptr,size_t size, size_t nmemb, FILE *stream)
{
	int rv = fread(ptr,size,nmemb,stream);
	if(-1 == rv) {
		fatal_error("safe_fread");
	}
	return(rv);
}

/*
 * print message close the file
 * and exit.
 */
void fatal_error(char *msg)
{
	perror(msg);
	fclose(fp);
	exit(1);
}


/**
 * read the super block.
 **/
struct ext2_super_block *read_sb()
{
	int rv;
	static struct ext2_super_block sb;
	
	fp = fopen("/dev/fd0","r");
	if(NULL == fp) {
		fatal_error("fopen");
	}
	
	rv = fseek(fp,BOOT_BLOCK_SIZE,SEEK_SET);
	if(-1 == rv) {
		fatal_error("fseek");
	}
	
	
	safe_fread(&sb,sizeof(sb),1,fp);
	block_size = (sb.s_log_block_size +1) * BOOT_BLOCK_SIZE;
	return(&sb);

			

}


/**
 * read the group descriptor
 */
struct ext2_group_desc *read_group_desc()
{
	static struct ext2_group_desc gdesc;
	safe_fread(&gdesc,sizeof(gdesc),1,fp);
	return(&gdesc);
}


/**
 * read an entry in the inode table.
 * entry - the entry number.
 */
struct ext2_inode *read_inode_table(int entry)
{
	static struct ext2_inode inode_tbl;
	int rv;
	
	rv = fseek(fp,block_size * (inode_table_block )+ sizeof(inode_tbl) * entry ,SEEK_SET);
	if(-1 == rv) {
		fatal_error("fseek");
	}
	
	safe_fread(&inode_tbl,sizeof(inode_tbl),EXT2_ROOT_INO - 1,fp);
	return(&inode_tbl);

}


/**
 * print a directory entry
 * entry - a pointer to a struct ext2_dir_entry_2 to print.
 */
void print_dir_entry(struct ext2_dir_entry_2 *entry)
{
	char stime[80];
	long currpos = ftell(fp);
	struct tm *tt;

	/*
	 * get the file time from the inode table.
	 * save current file position so 
	 * we could get back to the original position.
	 */
	struct ext2_inode *inode = read_inode_table(entry->inode);
	tt = localtime((time_t *)&inode->i_ctime);
	strftime(stime,80,"%d-%m-%Y %H:%M",tt);
	printf("%s\t",stime);

	/* restore file position */
	fseek(fp,currpos,SEEK_SET);
	
	switch(entry->file_type) {
		case EXT2_FT_DIR:
			printf("dir\t");
			break;
		case EXT2_FT_REG_FILE:
			printf("file\t");
			break;
		case EXT2_FT_FIFO:
			printf("fifo\t");
			break;
		case EXT2_FT_SYMLINK:
			printf("symlink\t");
			break;
		case EXT2_FT_SOCK:
			printf("sock\t");
			break;
		default:
			printf("other\t");
			break;
	
	}
	printf("%d\t%s\n",entry->inode,entry->name);


}


/*
 * fseek to the inode table entry and search for the 
 * path component.
 */
struct ext2_dir_entry_2 *find_entry(char *path, int inode, 
				void(* print_entry)(struct ext2_dir_entry_2 *))
{
	struct ext2_inode *inode_entry = read_inode_table(inode);
	static struct ext2_dir_entry_2 dir_entry;
	int rec_len =0,pos =0,found=0,curr_dir=0;
	int rv;


	
	rv = fseek(fp,block_size * inode_entry->i_block[0] ,SEEK_SET);
	if(-1 == rv) {
		fatal_error("fseek");
	}
	

	do {
		rv = fseek(fp,pos ,SEEK_CUR);
		if(-1 == rv) {
			fatal_error("fseek");
		}
		safe_fread(&dir_entry.inode,sizeof(dir_entry.inode),1,fp);
		safe_fread(&dir_entry.rec_len,sizeof(dir_entry.rec_len),1,fp);
		rec_len = dir_entry.rec_len;
		safe_fread(&dir_entry.name_len,sizeof(dir_entry.name_len),1,fp);
		safe_fread(&dir_entry.file_type,sizeof(__u8),1,fp);  
		safe_fread(&dir_entry.name,dir_entry.name_len,1,fp);
		dir_entry.name[dir_entry.name_len] = '\0';

		 if(dir_entry.inode == 0) break; 
		if(!strcmp(dir_entry.name,".")) {
			curr_dir++;
			if(curr_dir > 1) {
				break;
			}
		}
		if(!strcmp(path,dir_entry.name) ) {
				if(dir_entry.file_type != EXT2_FT_DIR) {
					found = 0;
					printf("%s is not a directory\n",path);
				} else{
					found = 1;
				}
				break;
		}
		pos = rec_len - sizeof(dir_entry.inode) - sizeof(dir_entry.rec_len) 
						- sizeof(dir_entry.name_len) -sizeof(__u8) - dir_entry.name_len;
		if(NULL != print_entry) {
			(*print_entry)(&dir_entry);
		}
	} while(1) ;
	return(found ? &dir_entry : NULL);

}


/**
 * find the full path.
 * break into path components and search for each path componenet.
 */
struct ext2_dir_entry_2 *find_path(char *full_path)
{
	int inode = 1,found=1;
	char *p;
	static struct ext2_dir_entry_2 *dir_entry;


	if(!strcmp(full_path,"/")) {
		dir_entry = find_entry(".",inode,NULL);	
	}

	p = strtok(full_path,"/");
	while(NULL != p) {
		dir_entry = find_entry(p,inode,NULL);	
		if(NULL == dir_entry) {
			found = 0;
			break;
		}
		inode = dir_entry->inode - 1;	
		p = strtok(NULL,"/");
	}
	
	return(found ? dir_entry : NULL);

}


/**
 * read the super block and group descriptor.
 * find the location of the inode table.
 */
void init()
{
	struct ext2_group_desc *gdesc;
	struct ext2_super_block *sb;

	sb = read_sb();
	gdesc = read_group_desc();
	inode_table_block = gdesc->bg_inode_table;

}


/**
 * close the file.
 **/
void cleanup()
{
	fclose(fp);
}


/**
 * set the default path by writing
 * it into the /tmp/.myext2 file.
 */
void set_path(char *path)
{
	FILE *fp = fopen(DIR_FNAME,"w");
	if(NULL == fp) {
		fatal_error("fopen");
	}
	
	fprintf(fp,path);
	fclose(fp);
}

/**
 * get the default path from
 * the file /tmp/.myext2
 */
char *get_default_dir()
{
	static char dir[MAX_PATH], *p;
	FILE *fp = fopen(DIR_FNAME,"r");
	if(NULL == fp) {
		strcpy(dir,"/");
		set_path(dir);
		return(dir);
	}

	p = fgets(dir,MAX_PATH,fp);
	return(p);

}
