var TREE_NODES = [
	['Technology Stuff', null, null,
		['News.com', 'http://www.news.com', '_top'],
                ['Slashdot.org', 'http://www.slashdot.org', '_top'],
		['Web Building', null, null,
			['JavaScript Kit', 'http://www.javascriptkit.com', '_top'],
			['Dynamic Drive', 'http://www.dynamicdrive.com', '_top'],
			['Freewarejava', 'http://freewarejava.com', '_top'],
		],
	],
	['News stuff', null, null,
			['CNN', 'http://www.cnn.com', '_top'],
			['MSNBC', 'http://www.msnbc.com', '_top'],
			['BBC News', 'http://news.bbc.co.uk', '_top'],
	]
];


