
#include <iostream.h>

void main(void)
{
	cout << "test ...." << endl;
}
