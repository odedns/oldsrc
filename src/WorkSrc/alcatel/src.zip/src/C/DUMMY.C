
void __crt0_glob_function()
{


}

void __crt0_load_environment_file()
{


}

void __crt0_setup_arguments()
{

}
