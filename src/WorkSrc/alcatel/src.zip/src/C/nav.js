<SCRIPT LANGUAGE="JavaScript">

<!-- This script and many more are available online from -->
<!-- The JavaScript Source!! http://javascriptsource.com -->

<!-- Begin
var xy = navigator.appVersion;
xz = xy.substring(0,4);
document.write("<center><table border=1 cellpadding=2><tr><td>");
document.write("<center><b>", navigator.appName,"</b>");
document.write("</td></tr><tr><td>");
document.write("<center><table border=1 cellpadding=2><tr>");
document.write("<td>Code Name: </td><td><center>");
document.write("<b>", navigator.appCodeName,"</td></tr>");
document.write("<tr><td>Version: </td><td><center>");
document.write("<b>",xz,"</td></tr>");
document.write("<tr><td>Platform: </td><td><center>");
document.write("<b>", navigator.platform,"</td></tr>");
document.write("<tr><td>Pages Viewed: </td><td><center>");
document.write("<b>", history.length," </td></tr>");
document.write("<tr><td>Java enabled: </td><td><center><b>");
if (navigator.javaEnabled()) 
	document.write("sure is!</td></tr>");
else 
	document.write("not today</td></tr>")
document.write("<tr><td>Screen Resolution: </td><td><center>");
document.write("<b>",screen.width," x ",screen.height,"</td></tr>");
document.write("</table></tr></td></table></center>");
// End -->
// </script>
//
// <!-- Script Size:  1.34 KB  -->
//
